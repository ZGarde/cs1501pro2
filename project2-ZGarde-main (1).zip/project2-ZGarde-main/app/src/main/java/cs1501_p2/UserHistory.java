package cs1501_p2;

import java.util.ArrayList;
import java.util.HashMap;

public class UserHistory implements Dict {
    private HashMap<String, Integer> historyMap;

    private StringBuilder searchString;

    public UserHistory() {
        historyMap = new HashMap<>();
        searchString = new StringBuilder();
    }

    @Override
    public void add(String key) {
        historyMap.put(key, historyMap.getOrDefault(key, 0) + 1);
    }

    @Override
    public boolean contains(String key) {
        if (historyMap == null || key == null || key.isEmpty()) {
            return false;
        }

        return historyMap.containsKey(key);
    }

    @Override
    public boolean containsPrefix(String pre) {
        if (historyMap == null || pre == null || pre.isEmpty()) {
            return false;
        }

        for (String key : historyMap.keySet()) {
            if (key.startsWith(pre) && !key.equals(pre)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public int searchByChar(char next) {
        searchString.append(next);

        boolean validWord = contains(searchString.toString());
        boolean validPrefix = containsPrefix(searchString.toString());

        if (validPrefix) {
            if (validWord) {
                return 2;
            }
            else {
                return 0;
            }
        }
        else {
            if (validWord) {
                return 1;
            }
            else {
                return -1;
            }
        }
    }

    @Override
    public void resetByChar() {
        searchString.setLength(0);
    }

    @Override
    public ArrayList<String> suggest() {
        ArrayList<String> suggestions = new ArrayList<>();
        for (String key : historyMap.keySet()) {
            if (key.startsWith(searchString.toString())) {
                suggestions.add(key);
            }
        }

        ArrayList<String> sortString = sortByValue(historyMap);

        ArrayList<String> orderSuggestions = new ArrayList<>();
        for (String s : sortString) {
            if (suggestions.contains(s)) {
                orderSuggestions.add(s);
            }
        }

        while (orderSuggestions.size() > 5) {
            orderSuggestions.remove(orderSuggestions.size() - 1);
        }

        return orderSuggestions;
    }

    public ArrayList<String> sortByValue(HashMap<String, Integer> map) {
        ArrayList<HashMap.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());

        list.sort(HashMap.Entry.comparingByValue());

        ArrayList<String> sortedKeys = new ArrayList<>();
        for (HashMap.Entry<String, Integer> entry : list) {
            sortedKeys.add(0, entry.getKey());
        }

        return sortedKeys;
    }

    @Override
    public ArrayList<String> traverse() {
        return new ArrayList<>(historyMap.keySet());
    }

    @Override
    public int count() {
        return historyMap.size();
    }
}
