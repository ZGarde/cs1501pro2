package cs1501_p2;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;


public class AutoCompleter implements AutoComplete_Inter {
    private DLB dlb;

    private UserHistory userHistory;

    private StringBuilder curWord;

    public AutoCompleter(String dictionaryFile, String userHistoryFile) {
        dlb = new DLB();
        userHistory = new UserHistory();
        curWord = new StringBuilder();

        try (Scanner s = new Scanner(new File(dictionaryFile))) {
            while (s.hasNext()) {
                dlb.add(s.nextLine());
            }
        } catch (IOException ignored) {
            ;
        }

        if (userHistoryFile != null) {
            try (Scanner s = new Scanner(new File(userHistoryFile))) {
                while (s.hasNext()) {
                    userHistory.add(s.nextLine());
                }
            } catch (IOException ignored) {
                ;
            }
        }
    }

    public AutoCompleter(String dictionaryFile) {
        this(dictionaryFile, null);
    }

    @Override
    public ArrayList<String> nextChar(char next) {
        curWord.append(next);
        dlb.searchByChar(next);
        userHistory.searchByChar(next);

        ArrayList<String> suggestions = new ArrayList<>();

        // suggestions from user history
        ArrayList<String> userHistorySuggestions = userHistory.suggest();
        suggestions.addAll(userHistorySuggestions);

        // If suggestions from user history are less than 5, get suggestions from dictionary
        int remaining = 5 - userHistorySuggestions.size();
        if (remaining > 0) {
            ArrayList<String> dictionarySuggestions = dlb.suggest();
            for (String suggestion : dictionarySuggestions) {
                if (remaining > 0 && !suggestions.contains(suggestion)) {
                    suggestions.add(suggestion);
                    remaining--;
                }
            }
        }

        return suggestions;
    }

    @Override
    public void finishWord(String cur) {
        userHistory.add(cur);

        curWord.setLength(0);
        dlb.resetByChar();
        userHistory.resetByChar();
    }

    @Override
    public void saveUserHistory(String fname) {
        if (fname == null) {
            return ;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fname))) {
            for (String s : userHistory.traverse()) {
                writer.write(s);
                writer.write("\n");
            }
        } catch (IOException ignored) {
            ;
        }
    }
}
