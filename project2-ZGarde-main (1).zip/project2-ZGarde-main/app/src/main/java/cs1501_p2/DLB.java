package cs1501_p2;

import java.util.ArrayList;

public class DLB implements Dict {
    private DLBNode root;

    private StringBuilder searchString;

    public DLB() {
        root = null;
        searchString = new StringBuilder();
    }

    @Override
    public void add(String key) {
        if (key == null || key.isEmpty()) {
            return;
        }

        if (root == null) {
            root = new DLBNode(key.charAt(0));
        }

        DLBNode cur = root;
        for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);

            while (cur.getLet() != c && cur.getRight() != null) {
                cur = cur.getRight();
            }

            if (i != key.length() - 1) {
                if (cur.getLet() == c) {
                    if (cur.getDown() != null) {
                        cur = cur.getDown();
                        if (cur.getLet() == '$') {
                            if (cur.getDown() == null) {
                                cur.setDown(new DLBNode(key.charAt(i + 1)));
                            }
                            cur = cur.getDown();
                        }
                    }
                    else {
                        cur.setDown(new DLBNode(key.charAt(i + 1)));
                        cur = cur.getDown();
                    }
                }
                else {
                    cur.setRight(new DLBNode(c));
                    cur = cur.getRight();
                    cur.setDown(new DLBNode(key.charAt(i + 1)));
                    cur = cur.getDown();
                }
            }
            else {
                if (cur.getLet() == c) {
                    if (cur.getDown() != null) {
                        if (cur.getDown().getLet() != '$') {
                            DLBNode temp = cur.getDown();
                            cur.setDown(new DLBNode('$'));
                            cur.getDown().setDown(temp);
                        }
                    }
                    else {
                        cur.setDown(new DLBNode('$'));
                    }
                }
                else {
                    cur.setRight(new DLBNode(c));
                    cur = cur.getRight();
                    cur.setDown(new DLBNode('$'));
                }
            }
        }
    }

    @Override
    public boolean contains(String key) {
        if (root == null || key == null || key.isEmpty()) {
            return false;
        }

        return search(root, key.toCharArray(), 0, false);
    }

    @Override
    public boolean containsPrefix(String pre) {
        if (root == null || pre == null || pre.isEmpty()) {
            return false;
        }

        return search(root, pre.toCharArray(), 0, true);
    }

    private boolean search(DLBNode node, char[] word, int index, boolean checkPrefix) {
        if (node != null && node.getLet() == '$') {
            return search(node.getDown(), word, index, checkPrefix);
        }

        while (node != null && node.getLet() != word[index]) {
            node = node.getRight();
        }

        if (node == null) {
            return false;
        }

        if (index == word.length - 1) {
            if (checkPrefix) {
                return (node.getDown() != null && (node.getDown().getLet() != '$' ||
                        node.getDown().getDown() != null));
            }
            else {
                return node.getDown() != null && node.getDown().getLet() == '$';
            }
        }
        else {
            return search(node.getDown(), word, index + 1, checkPrefix);
        }
    }

    @Override
    public int searchByChar(char next) {
        searchString.append(next);

        boolean validWord = contains(searchString.toString());
        boolean validPrefix = containsPrefix(searchString.toString());

        if (validPrefix) {
            if (validWord) {
                return 2;
            }
            else {
                return 0;
            }
        }
        else {
            if (validWord) {
                return 1;
            }
            else {
                return -1;
            }
        }
    }

    @Override
    public void resetByChar() {
        searchString.setLength(0);
    }

    @Override
    public ArrayList<String> suggest() {
        ArrayList<String> suggestions = new ArrayList<>();
        if (searchString.length() == 0 || root == null) {
            return suggestions;
        }

        DLBNode prefixNode = findPrefixNode(root, searchString.toString().toCharArray(), 0);

        if (prefixNode != null) {
            traverse(prefixNode.getDown(), searchString, suggestions);
        }

        while (suggestions.size() > 5) {
            suggestions.remove(suggestions.size() - 1);
        }

        sortSuggestions(suggestions);

        return suggestions;
    }

    private void sortSuggestions(ArrayList<String> suggestions) {
        int n = suggestions.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (suggestions.get(j).compareTo(suggestions.get(j + 1)) > 0) {
                    String temp = suggestions.get(j);
                    suggestions.set(j, suggestions.get(j + 1));
                    suggestions.set(j + 1, temp);
                }
            }
        }
    }

    private DLBNode findPrefixNode(DLBNode node, char[] prefix, int index) {
        while (node != null && node.getLet() != prefix[index]) {
            if (node.getLet() == '$') {
                node = node.getDown();
            }
            else {
                node = node.getRight();
            }
        }

        if (node == null) {
            return null;
        }

        if (index == prefix.length - 1) {
            return node;
        }

        return findPrefixNode(node.getDown(), prefix, index + 1);
    }

    @Override
    public ArrayList<String> traverse() {
        ArrayList<String> words = new ArrayList<>();
        StringBuilder word = new StringBuilder();
        traverse(root, word, words);
        return words;
    }

    private void traverse(DLBNode node, StringBuilder word, ArrayList<String> words) {
        if (node == null) {
            return;
        }

        word.append(node.getLet());
        if (node.getLet() == '$') {
            word.deleteCharAt(word.length() - 1);
            words.add(word.toString());
        }

        traverse(node.getDown(), word, words);
        if (node.getLet() != '$') {
            word.deleteCharAt(word.length() - 1);
        }
        traverse(node.getRight(), word, words);
    }


    @Override
    public int count() {
        return traverse().size();
    }
}
